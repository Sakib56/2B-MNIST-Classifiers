%
%
function task1_8(varargin)
%  NB: there is no specification to this function.


end
