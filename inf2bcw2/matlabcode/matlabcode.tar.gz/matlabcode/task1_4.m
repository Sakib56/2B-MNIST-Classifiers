%
%
function task1_4(EVecs)
% Input:
%  Evecs : the same format as in comp_pca.m
%


end
